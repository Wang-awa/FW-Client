package com.mucheng.mucuteuix.example.ui;
import com.mucheng.mucuteuix.effect.Hint;
import com.mucheng.mucuteuix.effect.Notification;
import com.mucheng.mucuteuix.example.callback.ItemCallback;
import com.mucheng.mucuteuix.example.callback.ItemCallbackAdapter;
import android.content.Context;
import android.os.Vibrator;
import com.mucheng.mucuteuix.example.callback.ItemCallbackAdapter;

public class MoveGUI extends MoveMenu {

  private static boolean isOpenMenu = true;

  private static boolean isPositionInit = false;

  private static int menuX;

  private static int menuY;
	private static MoveButton flyButton;

	private static boolean flyButtonShown;
  @Override
  protected void init() {
    if (!isPositionInit) {
      if (isLandscape()) {
        menuX = (int) (W() * 0.36) + dip2pxInt(50);
        menuY = dip2pxInt(60);
      } else {
        menuX = (int) (W() * 0.18) + dip2pxInt(40);
        menuY = W() / 4;
      }
      isPositionInit = true;
    }
    super.init();
  }

  @Override
  protected int getX() {
    return menuX;
  }

  @Override
  protected int getY() {
    return menuY;
  }

  @Override
  protected void setX(int x) {
    menuX = x;
  }

  @Override
  protected void setY(int y) {
    menuY = y;
  }

  @Override
  protected String getTitle() {
    return "移动";
  }

  @Override
  protected void onAddItems() {
	  addStateItem("fly", flyButtonShown, new ItemCallback() {


			  @Override
			  public void onClick() {
				  new Hint()
					  .setMessage("你点击了状态按钮")
					  .show();
			  }

			  @Override
			  public boolean onLongClick() {
				  Vibrator vibrator = (Vibrator) requireActivity().getSystemService(Context.VIBRATOR_SERVICE);
				  vibrator.vibrate(50L);

				  StringBuilder builder = new StringBuilder();
				  int count = 10;
				  for (int index = 0; index < count; index++) {
					  builder.append("The message content: ").append(index);
					  if (index + 1 < count) {
						  builder.append("\n");
					  }
				  }

				  new GUIBox()
					  .setTitle("fly Settings")
					  .setMessage(builder.toString())
					  .setCancelable(true)
					  .show();
				  return false;
			  }

			  @Override
			  public void onChecked(boolean isChecked) {
				  if (flyButton == null) {
					  flyButton = new MoveButton()
						  .setText("fly-pro")
						  .setStateful(false)
						  .setPosition(SystemW() - dip2pxInt(200), SystemH() / 2);
				  }
				  if (isChecked) {
					  flyButton.show();
					  MIX.notification.make(
						  "fly - Button",
						  "Enabled",
						  Notification.Type.SUCCESS
					  );
				  } else {
					  flyButton.dismiss();
					  MIX.notification.make(
						  "fly - Button",
						  "Disabled",
						  Notification.Type.ERROR
					  );
				  }
				  flyButtonShown = isChecked;
			  }
		  });
  }

  @Override
  public boolean isOpenMenu() {
    return isOpenMenu;
  }

  @Override
  protected void setOpenMenu(boolean openMenu) {
    isOpenMenu = openMenu;
  }
}
