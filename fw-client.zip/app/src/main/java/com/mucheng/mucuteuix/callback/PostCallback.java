package com.mucheng.mucuteuix.callback;

public interface PostCallback {

  void onPost(int width, int height);

}
