package com.mucheng.mucuteuix.callback;

import android.graphics.Canvas;

public interface CrossBlurCallback {

  void onDraw(Canvas canvas, int width, int height);

}
