package com.mucheng.mucuteuix.callback;

public interface GlobalLayoutCallback {

  void onGlobalLayout(int width, int height);

}
