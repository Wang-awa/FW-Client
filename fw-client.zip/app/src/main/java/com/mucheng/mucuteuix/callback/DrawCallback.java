package com.mucheng.mucuteuix.callback;

import android.graphics.Canvas;

public interface DrawCallback {

  void onDrawView(Canvas canvas);

}
