package com.mucheng.mucuteuix.example.callback;

public class ItemCallbackAdapter implements ItemCallback {

  @Override
  public void onClick() {
  }

  @Override
  public boolean onLongClick() {
    return false;
  }

  @Override
  public void onChecked(boolean isChecked) {
  }

}
