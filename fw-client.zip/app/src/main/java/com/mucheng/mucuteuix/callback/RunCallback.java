package com.mucheng.mucuteuix.callback;

public interface RunCallback {

  void onRun();

}
