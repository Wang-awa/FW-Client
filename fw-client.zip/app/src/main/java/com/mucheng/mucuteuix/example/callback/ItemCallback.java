package com.mucheng.mucuteuix.example.callback;

public interface ItemCallback {

  void onClick();

  boolean onLongClick();

  void onChecked(boolean isChecked);

}
